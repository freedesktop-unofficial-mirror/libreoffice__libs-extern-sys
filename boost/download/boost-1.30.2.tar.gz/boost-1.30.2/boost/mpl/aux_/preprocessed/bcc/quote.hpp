// preprocessed version of 'boost/mpl/quote.hpp' header
// see the original for copyright information

